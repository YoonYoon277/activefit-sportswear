/**
 * ActiveFit Sportswear
 * Main JavaScript file
 * Contains functionality for the website including:
 * - Form validation
 * - Product filtering
 * - Image gallery
 * - UI enhancements
 */

// Wait for DOM content to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all tooltips
    initTooltips();
    
    // Add animation classes to elements when they come into view
    initScrollAnimations();
    
    // Add event listeners to product filters
    initProductFilters();
    
    // Initialize form validation
    initFormValidation();
    
    // Initialize quantity selectors for product pages
    initQuantitySelectors();
    
    // Initialize mobile navigation
    initMobileNav();
    
    // Initialize any carousels
    initCarousels();
    
    console.log('ActiveFit JS initialized successfully');
});

/**
 * Initialize Bootstrap tooltips
 */
function initTooltips() {
    // Check if Bootstrap is loaded
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

/**
 * Add animation classes to elements when they come into view
 */
function initScrollAnimations() {
    // Add 'fade-in' class to elements with 'animate-on-scroll' class
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    if (animatedElements.length > 0) {
        // Create an intersection observer
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        // Observe each element
        animatedElements.forEach(element => {
            observer.observe(element);
        });
    }
}

/**
 * Initialize product filtering functionality
 */
function initProductFilters() {
    // Check if we're on the products page
    const categoryFilter = document.getElementById('categoryFilter');
    const sortOrder = document.getElementById('sortOrder');
    const productsContainer = document.getElementById('productsContainer');
    
    if (categoryFilter && sortOrder && productsContainer) {
        const productItems = document.querySelectorAll('.product-item');
        
        // Filter products by category
        categoryFilter.addEventListener('change', function() {
            const selectedCategory = this.value;
            
            productItems.forEach(item => {
                if (selectedCategory === 'all' || item.getAttribute('data-category') === selectedCategory) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
        
        // Sort products
        sortOrder.addEventListener('change', function() {
            const selectedSort = this.value;
            const productItemsArray = Array.from(productItems);
            
            productItemsArray.sort((a, b) => {
                const priceA = parseFloat(a.querySelector('.text-primary').textContent.replace('$', ''));
                const priceB = parseFloat(b.querySelector('.text-primary').textContent.replace('$', ''));
                const nameA = a.querySelector('.card-title').textContent;
                const nameB = b.querySelector('.card-title').textContent;
                
                if (selectedSort === 'price-low') {
                    return priceA - priceB;
                } else if (selectedSort === 'price-high') {
                    return priceB - priceA;
                } else if (selectedSort === 'name-asc') {
                    return nameA.localeCompare(nameB);
                }
                // For 'featured', maintain original order
                return 0;
            });
            
            // Remove all products and re-append in sorted order
            productItemsArray.forEach(item => productsContainer.appendChild(item));
        });
    }
}

/**
 * Initialize form validation
 */
function initFormValidation() {
    // Bootstrap form validation
    const forms = document.querySelectorAll('.needs-validation');
    
    if (forms.length > 0) {
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                
                form.classList.add('was-validated');
            }, false);
        });
    }
    
    // Custom validation for inquiry form
    const inquiryForm = document.getElementById('inquiryForm');
    if (inquiryForm) {
        const inquiryType = document.getElementById('inquiryType');
        const orderNumberField = document.getElementById('orderNumber');
        
        // If inquiry type changes, check if order number should be required
        if (inquiryType && orderNumberField) {
            inquiryType.addEventListener('change', function() {
                if (this.value === 'order' || this.value === 'return') {
                    orderNumberField.setAttribute('required', '');
                    orderNumberField.parentElement.querySelector('label').innerHTML = 'Order Number <span class="text-danger">*</span>';
                } else {
                    orderNumberField.removeAttribute('required');
                    orderNumberField.parentElement.querySelector('label').innerHTML = 'Order Number (if applicable)';
                }
            });
        }
    }
}

/**
 * Initialize quantity selectors on product pages
 */
function initQuantitySelectors() {
    const qtyInput = document.getElementById('qty');
    const decreaseBtn = document.getElementById('decrease-qty');
    const increaseBtn = document.getElementById('increase-qty');
    
    if (qtyInput && decreaseBtn && increaseBtn) {
        decreaseBtn.addEventListener('click', function() {
            let currentQty = parseInt(qtyInput.value);
            if (currentQty > 1) {
                qtyInput.value = currentQty - 1;
            }
        });
        
        increaseBtn.addEventListener('click', function() {
            let currentQty = parseInt(qtyInput.value);
            qtyInput.value = currentQty + 1;
        });
    }
    
    // Color selector functionality
    const colorOptions = document.querySelectorAll('.color-option');
    
    if (colorOptions.length > 0) {
        colorOptions.forEach(option => {
            option.addEventListener('click', function() {
                // Remove active class from all options
                colorOptions.forEach(opt => opt.classList.remove('active'));
                // Add active class to clicked option
                this.classList.add('active');
                
                console.log(`Selected color: ${this.getAttribute('data-color')}`);
            });
        });
    }
}

/**
 * Initialize mobile navigation functionality
 */
function initMobileNav() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        // Close mobile menu when clicking a nav link
        const navLinks = navbarCollapse.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth < 992) {  // Bootstrap's lg breakpoint
                    navbarCollapse.classList.remove('show');
                }
            });
        });
    }
}

/**
 * Initialize carousels functionality
 */
function initCarousels() {
    // Check if Bootstrap is loaded
    if (typeof bootstrap !== 'undefined') {
        const carouselList = [].slice.call(document.querySelectorAll('.carousel'));
        carouselList.map(function(carouselEl) {
            return new bootstrap.Carousel(carouselEl, {
                interval: 5000,
                wrap: true
            });
        });
    }
}

/**
 * Add item to cart (simulation for demo)
 * @param {number} productId - The ID of the product
 * @param {string} productName - The name of the product
 * @param {number} price - The price of the product
 * @param {number} quantity - The quantity to add
 */
function addToCart(productId, productName, price, quantity = 1) {
    console.log(`Added to cart: ${productName} (ID: ${productId}), Price: $${price}, Quantity: ${quantity}`);
    
    // Show a notification to the user
    const toast = document.createElement('div');
    toast.className = 'position-fixed top-0 end-0 p-3';
    toast.style.zIndex = 1050;
    toast.innerHTML = `
        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto">Item Added</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${productName} has been added to your cart.
            </div>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Show toast if Bootstrap is loaded
    if (typeof bootstrap !== 'undefined') {
        const toastElement = toast.querySelector('.toast');
        const bsToast = new bootstrap.Toast(toastElement);
        bsToast.show();
        
        // Remove toast element after it's hidden
        toastElement.addEventListener('hidden.bs.toast', function() {
            document.body.removeChild(toast);
        });
    }
}

/**
 * Handle inquiry form submission
 * @param {Event} event - The form submission event
 */
function handleInquirySubmit(event) {
    const form = event.target;
    
    // Check form validity using the Constraint Validation API
    if (form.checkValidity()) {
        // Prevent default form submission
        event.preventDefault();
        
        // Collect form data
        const formData = new FormData(form);
        const formDataObj = Object.fromEntries(formData.entries());
        
        // Log form data (for demonstration)
        console.log('Form data:', formDataObj);
        
        // Show success message
        const successAlert = document.createElement('div');
        successAlert.className = 'alert alert-success alert-dismissible fade show mt-3';
        successAlert.setAttribute('role', 'alert');
        successAlert.innerHTML = `
            <strong>Thank you for your inquiry!</strong> We will get back to you shortly.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        // Insert alert before the form
        form.parentNode.insertBefore(successAlert, form);
        
        // Reset the form
        form.reset();
        form.classList.remove('was-validated');
        
        // Scroll to the top of the form container
        form.parentNode.scrollIntoView({ behavior: 'smooth' });
    }
}

/**
 * Toggle wishlist status for a product
 * @param {Element} button - The wishlist button element
 */
function toggleWishlist(button) {
    const isActive = button.classList.contains('active');
    
    if (isActive) {
        button.classList.remove('active');
        button.innerHTML = '<i class="far fa-heart"></i>';
    } else {
        button.classList.add('active');
        button.innerHTML = '<i class="fas fa-heart text-danger"></i>';
    }
}
